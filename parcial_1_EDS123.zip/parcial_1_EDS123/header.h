/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   header.h
 * Author: samus
 *
 * Created on 6 de septiembre de 2021, 10:32
 */
#include <stdio.h>
#include <stdlib.h>
#ifndef HEADER_H
#define HEADER_H

int extraer(char *direccion);
int transponer();
int Multiplicacion();
int leer_archivo (char *direccion);
int carnes();

#endif /* HEADER_H */

